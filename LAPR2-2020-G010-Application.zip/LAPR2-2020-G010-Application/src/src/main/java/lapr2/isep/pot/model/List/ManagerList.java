package lapr2.isep.pot.model.List;

import java.io.Serializable;

public class ManagerList implements Serializable {
}
